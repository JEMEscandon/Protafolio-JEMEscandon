// JavaScript Document
	function validar(){
			let usuario=document.getElementById("usuario").value;
			let pass=document.getElementById("password").value;
			let exreg= /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@#._-])[A-Za-z\d$@#._-]{8,16}/;
			
			if(usuario==="" || pass===""){
				window.alert("Falta llenar un campo");
			}
			else{
				if(!(/^[A-Z]{2}\d{2}$/.test(usuario))){
				alert("¡ATENCION! Usuario incorrecto");
				alert("¡RECUERDA! El usuario se conforma por la primera letra del nombre y cada uno de los apellidos (2 caracteres) y el día de nacimiento en formato de dos dígitos.");
			}else if(!(exreg.test(pass))){
				alert("¡ATENCION! Contraseña incorrecta");
				alert("¡RECUERDA! Para la contraseña se debe tener de 8 a 16 caracteres donde incluya al menos una mayúscula, una minúscula un número y un carácter especial.");
				}else{
					window.alert("¡ACCESO PERMITIDO!");
					window.location="Registro.html";
				}	
			}
	}


	function registro(){
		let empleado=document.getElementById("empleado").value;
		let nombre=document.getElementById("nombre").value;
		let telefono=document.getElementById("telefono").value;
		let correo=document.getElementById("correo").value;
		let fecha=document.getElementById("fecha").value;
		
		let exreg=/^([a-zA-Z0-9_\.\-])+\@(([patito])+\.)+([a-zA-Z]{2,4})+$/;
		
		if(empleado==="" || nombre==="" || telefono==="" || correo==="" || fecha===""){
				window.alert("Falta llenar un campo");
			}
			else{
				if(!(/^\d{5}$/.test(empleado))){
				alert("¡ATENCION! Número de empleado incorrecto.");
				}else if(!(/^[A-Za-z\s]{1,60}$/.test(nombre))){
					alert("¡ATENCION! Nombre de empleado incorrecto.");
				}else if(!(/^\d{3}-\d{3}-\d{4}$/.test(telefono))){
					alert("¡ATENCION! Número de teléfono incorrecto.");
				}else if(!(exreg.test(correo))){
					alert("¡ATENCION! Correo electrónico incorrecto.");
					alert("¡RECUERDA! El correo es el institucional con el dominio @patito.");
				}else if(!(/^\d{2}[/]\d{2}[/]\d{4}$/.test(fecha))){
					alert("Formato de fecha incorrecto.");
				}else{
					window.alert("¡DATOS REGISTRADOS CORRECTAMENTE!");
					window.location="Salario.html";
				}
			}
	}


function salario(){
			let horas=parseFloat(document.formulario.hora.value);
			let antiguedad=parseFloat(document.formulario.antiguedad.value);
			let ex=0;
			let extra=0;
			let textra=0;
			let normal=0;
			let resanti=0;
			let total=0;
	
			if(horas>=41){
				ex=horas-41;
				extra=ex*150;
				normal=(horas-ex)*75.50;
				textra=extra+normal;
				if(antiguedad>=4 ){
					resanti=normal*.12;
				}
				total=textra+resanti;
			}else {
				normal=horas*75.50;
				extra=0;
				textra=extra+normal;
				if(antiguedad>=4 ){
					resanti=normal*.12;
				}
				total=textra+resanti;
			}
	
			document.formulario.saldo.value=("$"+normal+".00");
			document.formulario.extra.value=("$"+extra+".00");
			document.formulario.anti.value=("$"+resanti+".00");
			document.formulario.total.value=("$"+total+".00");
		}

