<?php
require_once "conexion.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verificar si los campos están vacíos o si el email no es válido
    if (
        empty($_POST['name']) ||
        empty($_POST['subject']) ||
        empty($_POST['message']) ||
        !filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)
    ) {
        http_response_code(500);
        exit();
    }

    // Sanitizar datos recibidos del formulario
    $name = strip_tags(htmlspecialchars($_POST['name']));
    $email = strip_tags(htmlspecialchars($_POST['email']));
    $subject = strip_tags(htmlspecialchars($_POST['subject']));
    $message = strip_tags(htmlspecialchars($_POST['message']));

    // Insertar datos en la base de datos utilizando una consulta preparada
    $stmt = $conexion->prepare("INSERT INTO contacto (name, email, subject, message) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $name, $email, $subject, $message);
    $stmt->execute();

    // Configuración para enviar un correo electrónico
    $to = "jmartinez.depad.lm@gmail.com";
    $subjectEmail = "$subject: $name";
    $body = "Has recibido un nuevo mensaje desde el formulario de contacto de tu sitio web.\n\n" .
        "Aquí están los detalles:\n\nName: $name\n\nEmail: $email\n\nSubject: $subject\n\nMessage: $message";
    $header = "From: $email";
    $header .= "Reply-To: $email";

    // Intentar enviar el correo electrónico después de la inserción
    if (mail($to, $subjectEmail, $body, $header)) {
        // Redireccionar después del envío del correo electrónico
        header("Location: ../formulario.html");
        exit(); // Asegura que el script se detenga después de redirigir
    } else {
        // En caso de fallo al enviar el correo, mostrar un mensaje de error
        echo "Lo sentimos, parece que nuestro servidor de correo no responde. Por favor, inténtelo de nuevo más tarde.";
    }
}
?>