<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Registrar</title>
</head>

<body>
	<h1 align="center">Guardar datos</h1>
	<?php
		include("Conexion.php");
		$con=Conectar();
	
		if($_POST){
			$id_cliente=$_POST['id_cliente'];
			$nombre=$_POST['nombre'];
			$tel=$_POST['tel'];
			$correo=$_POST["correo"];
			$pago=$_POST['pago'];
			$habitacion=$_POST["habitacion"]
			
			//Instruccion SQL		
			mysqli_query("INSERT INTO cliente(id_cliente, nombre, telefono, correo, pago, tipo_habitacion) VALUES ('$id_cliente', '$nombre', '$tel', '$correo', '$pago', '$habitacion')") or die("ERROR".mysqli_error());
			echo "Datos Guardados";

		}
	?>
</body>
</html>