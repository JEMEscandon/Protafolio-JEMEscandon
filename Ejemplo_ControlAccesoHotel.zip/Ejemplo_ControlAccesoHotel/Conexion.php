<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<title>Conexion.php</title>
</head>

<body>
	<?php
		function Conectar(){
			$server="localhost";
			$user="root";
			$pass="";
			$db="empresa";
			
			$conexion=mysql_connect($server,$user,$pass) or die("Error en la conexion con la BD").mysql_error();
			mysql_select_db($db,$conexion);
			
			return $conexion;
		}
	
	?>
</body>
</html>