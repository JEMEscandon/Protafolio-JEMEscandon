<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Eliminar</title>
</head>

<body>
	<?php
	include ("P5ConexionPas.php");
	$con=conectar();
	
	if($_POST){
		$id=$_POST['Id_cliente'];
			if($id==""){
				echo "Escribe el id del cliente: ";
			}
			else{
				mysql_query("DELETE clientes WHERE Id_cliente='$id'") or die("Error".mysql_error);
				echo "Datos eliminados.";
			}
	}
	?>
</body>
</html>
