<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Buscar</title>
</head>

<body>
	<?php
	include ("P5ConexionPas.php");
	$con=conectar();
			
	
	if($_POST){
		$id=$_POST['id_cliente'];
			if($id==""){
				echo "Escribe el ID.";
			}
			else{
				$resultado=mysql_query("SELECT * FROM  clientes WHERE id_cliente='$id'") or die("Error".mysql_error);
				echo"<table align='center' border='1'>";
				echo "<tr>";
				echo "<th>id_cliente</th>";
				echo "<th>nombre</th>";
				echo "<th>telefono</th>";
				echo "<th>correo</th>";
				echo "<th>tipo_pago</th>";
				echo "<th>habitaciones</th>";
				echo "<th>costo</th>";
				echo "<th>tipoHab</th>";
				echo "<th>estado</th>";
				echo "</tr>";
				
				
				while($campo=mysql_fetch_array($resultado)){
					echo "<tr>";
					echo "<td>".$campo['id_cliente']."</td>";
					echo "<td>".$campo['nombre']."</td>";
					echo "<td>".$campo['telefono']."</td>";
					echo "<td>".$campo['correo']."</td>";
					echo "<td>".$campo['tipo_pago']."</td>";
					echo "<td>".$campo['habitaciones']."</td>";
					echo "<td>".$campo['costo']."</td>";
					echo "<td>".$campo['tipoHab']."</td>";
					echo "<td>".$campo['estado']."</td>";
					echo "</tr>";
				}
			}
		}
	?>
</body>
</html>

