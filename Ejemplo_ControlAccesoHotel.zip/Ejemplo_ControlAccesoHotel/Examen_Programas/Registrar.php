<!DOCTYPE html>
<html>
<head>
    
<title>
   <h1>Registro de base</h1> 
</title>
 
</head>
<body id="cuerpo"><!--conectar para hacer el archivo -->
<?php
include('P5ConexionPas.php');//llamar al archivo conexion 
$conexion=conectar();//Se almacena la respuesta de la conexion 

if($_POST){//si se envio la informacion
    $id=$_POST['id_cliente'];
    $nombre=$_POST['nombre'];
    $telefono=$_POST['telefono'];
    $corr=$_POST['correo'];
    $tipo_pa=$_POST['tipo_pago'];
    $habitaciones=$_POST['habitaciones'];
    $costo=$_POST['costo'];
    $tipo_ha=$_POST['tipoHab'];
    $estado=$_POST['estado'];
    //registrar
    mysqli_query($conexion,"INSERT INTO clientes(Id_cliente,Nombre,Telefono,Correo,Tipo_pago,Habitaciones,Costo,Tipo_habitaciones,Estado
    ) VALUES ('$id','$nombre','$telefono','$corr','$tipo_pa','$habitaciones','$costo','$tipo_ha','$estado')") or die("Error....".mysqli_error());
    echo "Datos guardados ";


}
?>   
</body>
</html>