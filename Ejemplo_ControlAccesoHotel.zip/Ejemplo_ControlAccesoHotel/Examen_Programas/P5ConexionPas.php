<!DOCTYPE html>
<html>
<head>
    
<title>
   <h1>Registro</h1>
</title>

</head>
<body id="cuerpo"><!--conectar para hacer el archivo -->
<?php
function conectar(){

    $_SERVER="localhost";
    $Usert="root";
    $Passwor="";
    $BD="horafeliz";
    $conexion=mysqli_connect($_SERVER,$Usert,$Passwor)or die("Error de conexion...".mysqli_error());
    mysqli_select_db($conexion,$BD);
    return ($conexion);
}


?>   
</body>
</html>