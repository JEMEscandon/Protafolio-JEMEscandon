<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Prac6.Eliminar</title>
</head>

<body>
	<?php
		include("Prac4.Conexion.php");
		$con=conectar();
		
		
		if($_POST){
			$id_emp=$_POST['id_empleado'];
			if($id_emp==""){
				echo "Escribe el id del empleado";
				
			}else{
				mysqli_query($con,"DELETE FROM empleados WHERE id_empleado='$id_emp'") or die("ERROR".mysqli_error);
				echo "Datos eliminados";
			}
		}
	?>
</body>
</html>