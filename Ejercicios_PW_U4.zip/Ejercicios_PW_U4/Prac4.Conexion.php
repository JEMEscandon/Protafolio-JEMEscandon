<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<title>Prac4.Conexion.php</title>
</head>

<body>
	<?php
		function conectar(){
			$server="localhost";
			$user="root";
			$pass="";
			$db="empresa";
			
			$con=mysqli_connect($server,$user,$pass,$db) or die("Error en la conexion: ".mysqli_error);
			
			return $con;
		}
	
	?>
</body>
</html>