<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<title>Prac8.Actualizar</title>
</head>

<body>
	<?php
		include("Prac4.Conexion.php");
		$con=conectar();
	
		if($_POST){
			$id_emp=$_POST['id_empleado'];
			$nom=$_POST['nombre'];
			$dir=$_POST['dir'];
			$tel=$_POST['tel'];
			$salario=$_POST['salario'];
			
			if(isset($id_emp)){
				$resultado=mysqli_query($con,"SELECT * FROM empleados WHERE id_empleado='$id_emp'") or die ("ERROR".mysqli_error);
				$campo=mysqli_fetch_array($resultado);
				if($campo['id_empleado']=$id_emp){
					mysqli_query($con,"UPDATE empleados SET id_empleado='$id_emp',nombre_em='$nom',direccion_em='$dir',tel_em='$tel',salario_em='$salario' WHERE id_empleado='$id_emp'") or die ("ERROR".mysqli_error);
					echo "Datos actualizados";
				}else{
					echo "Datos no encontrados";
				}
				}else{
					echo "Escribe el id del empleado";
				}
			}
		
	?>
</body>
</html>