<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<title>Documento sin título</title>
</head>

<body>
	<?php
		include("Prac4.Conexion.php");
		$con=conectar();
		
		
		if($_POST){
			$id_emp=$_POST['id_empleado'];
			if($id_emp==""){
				echo "Escribe el id del empleado";
				
			}else{
				$resultado=mysqli_query($con,"SELECT * FROM empleados WHERE id_empleado='$id_emp'") or die ("ERROR".mysqli_error);
				echo "<table border='1'>";
				echo "<tr>";
				echo "<th>Id_empleado: </th>";
				echo "<th>Nombre: </th>";
				echo "<th>Direccion: </th>";
				echo "<th>Telefono: </th>";
				echo "<th>Salario: </th>";
				echo "</tr>";
				
				while($campo=mysqli_fetch_array($resultado)){
					echo "<tr>";
					echo "<td>".$campo['id_empleado']."</td> <td>".$campo['nombre_em']."</td> <td>".$campo['direccion_em']."</td><td>".$campo['tel_em']."</td> <td>".$campo['salario_em']."</td>";
					echo "</tr>";
						
				}
			}
			}
	?>
</body>
</html>