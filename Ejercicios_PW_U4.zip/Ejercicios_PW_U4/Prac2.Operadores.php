<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<title>Practica2</title>
</head>

<body>
	<h1 align="center">OPERADORES</h1>
	<?php
		$num1=7.5;
		$num2=10;
		$num3=1;
	
		//Operadores aritmeticos
		echo "<h3>OPERADORES ARITMETICOS</h3>";
		echo 'La suma es: ', $num1+$num2,"<br>";
		echo 'La resta es: ',$num2-$num1,"<br>";
		echo 'El producto es: ', $num1*$num2,"<br>";
		echo 'El cociente es: ', $num2/$num1,"<br>";
		echo 'El residuo es: ', $num2%$num1,"<br>";
		$num3++;
		echo 'El incremento es:', $num3,"<br>";
		$num2--;
		echo 'El decremento es: ', $num2,"<br>";
	
		//Operadores relacionales
		echo "<h3>OPERADORES RELACIONALES</h3>";
		echo $num1==$num2,"<br>";
		echo $num1!=$num3,"<br>";
		echo $num1<$num2,"<br>";
		echo $num1>$num2,"<br>";
		echo $num3<=$num2,"<br>";
		echo $num2>=$num3,"<br>";
	
		//Operadores logicos
		echo "<h3>OPERADORES LOGICOS</h3>";
		echo ($num1<$num2) && ($num2!=$num3),"<br>";
		echo ($num1<$num2) and ($num2!=$num3),"<br>";
		echo ($num2>=$num3) || ($num1==$num3),"<br>";
		echo ($num2>=$num3) or ($num1==$num3),"<br>";
		echo !($num2<$num3),"<br>";
	
	?>
</body>
</html>