<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<title>Practica1</title>
</head>

<body>
	<?php
		//Definir variables
		$cadena='Gabriel';
		$num=100;
		$num2=9.8;
		//Definir constantes
		define('PI',3.1416,true);
	
		//Ejemplo de mensajes
		echo 'Hola Mundo',"<br>";
		echo 'Las variables son: ',"<br>", $cadena, "<br>",$num,"<br>",$num2,"<br>";
		echo 'La variable constante es:',"<br>",PI;
	?>
</body>
</html>