<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<title>Practica 3. Enviar</title>
</head>

<body>
	<h2 align="center">DATOS DEL FORMULARIO</h2>
	<?php
		echo 'Nombre: '.$_POST['nombre']."<br>";
		echo 'Carrera: '.$_POST['carrera']."<br>";
		echo 'Deporte Favorito: '.$_POST['deporte']."<br>";
		echo 'Equipo favorito: '.$_POST['equipo']."<br>";
	
	
		if(isset($_POST['equipo']) && $_POST['equipo']=='America'){
			echo 'Poderosisimas Aguilas de America',"<br>";
		}else{
			echo 'No sabes de futbol';
		}
	
		if(isset($_POST['deporte']) && $_POST['equipo']=='Futbol'){
			echo 'Te gusta la Futbol';
		}else{
			if(isset($_POST['deporte']) && $_POST['equipo']=='Volleyball'){
			echo 'Te gusta la Volleyball';
		}else{
			if(isset($_POST['deporte']) && $_POST['equipo']=='Natacion'){
			echo 'Te gusta la Natacion';
		}else{
				echo 'No seleccionaste ninguno';
			}}}
	
	
		echo "<br>";
		echo "<br>";
		echo "<br>";
		echo "<a href='Prac3.Formulario.html'>Regresar</a>";
	?>
</body>
</html>