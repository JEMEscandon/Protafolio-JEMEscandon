<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Prac5.Registrar</title>
</head>

<body>
	<?php
		include("Prac4.Conexion.php");
		$con=conectar();
	
		if($_POST){
			$id_emp=$_POST['id_empleado'];
			$nom=$_POST['nombre'];
			$dir=$_POST['dir'];
			$tel=$_POST['tel'];
			$salario=$_POST['salario'];
			
			//Instruccion SQL
			mysqli_query($con,"INSERT INTO
			empleados(id_empleado,nombre_em,direccion_em,tel_em,salario_em) VALUES('$id_emp','$nom','$dir','$tel','$salario')") or die ("ERROR".mysql_error);
			echo "Datos Guardados";
			
		}
	?>
</body>
</html>